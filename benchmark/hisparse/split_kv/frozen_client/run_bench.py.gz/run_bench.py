import ctypes
import runpy
import sys

ctypes.CDLL(None).prctl(41, 1, 0, 0, 0)
script=sys.argv.pop(1)
sys.argv[0]=script
runpy.run_path(script,run_name='__main__')
